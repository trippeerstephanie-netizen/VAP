Louisville Property & Land Use Explorer — 2026

PUBLICATION:
1. Upload index.html to the root of a GitHub repository.
2. Settings > Pages > Deploy from a branch > main > /(root).
3. The resulting github.io URL is the public map.

This map uses OpenStreetMap tiles and Leaflet from public CDNs. No API key is required. Internet access is required for the basemap and Leaflet library. All seven GIS datasets are embedded directly in index.html, so no separate GeoJSON files are required on the server.
